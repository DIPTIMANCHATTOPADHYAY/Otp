from telethon.sync import TelegramClient

SESSION_NAME = "temp_1211362365.session"  # Changed from phone number
API_ID = 20094764
API_HASH = "ac33c77cfdbe4f94ebd73dde27b4a10c"

client = TelegramClient(SESSION_NAME, API_ID, API_HASH)

try:
    with client:
        telegram_user = client.get_entity(777000)
        print(f"👤 Chat Info:\nName: {telegram_user.first_name}\nUser ID: {telegram_user.id}\nUsername: @{telegram_user.username}")
        
        messages = client.get_messages(telegram_user, limit=5)
        print("\n📩 Last 5 messages from @Telegram:")
        for i, msg in enumerate(messages, 1):
            print(f"\n[{i}] {msg.date.strftime('%Y-%m-%d %H:%M:%S')}\n{msg.message}")
finally:
    client.disconnect()